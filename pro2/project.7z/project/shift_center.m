I = imread('eight.tif');
imshow(I);
j=fftshift(I);
imshow(j)
