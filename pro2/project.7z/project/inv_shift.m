I = imread('eight.tif');
imshow(I);
j=ifftshift(I);
imshow(j)
